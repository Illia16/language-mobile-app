const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB({
  region: "us-east-1",
  apiVersion: "2012-08-10",
});

exports.handler = async (event, context, callback) => {
    console.log("start...");
    const getData = new Promise((resolve, reject) => {
        console.log('getting data....');
        dynamoDB.scan({ TableName: "languageAppIn" }, (err, data) => {
            if (err) {
                reject(err);
            } else {
                const unmarshalledData = data.Items.map((el) => {
                    return AWS.DynamoDB.Converter.unmarshall(el);
                });

            const response = {
                statusCode: 200,
                body: JSON.stringify(unmarshalledData),
                headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
                },
            };
            console.log("resolving....");
            resolve(response);
        }
      });
    });

    return getData;
    // return getData.then((val) => {console.log('resolved val:', val); callback(null, val)});

    // getData.then((val) => {
    //     console.log("resolved val", val);
    // })
    // .catch((e) => {
    //     console.log("error", e);
    // });
};
